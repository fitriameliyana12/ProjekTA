<!DOCTYPE html>
<html>

<head>
  <title></title>
</head>

<body>
  <h1>Daftar Absensi Siswa</h1><br>
  <table border="5">
    <thead>
      <th>No</th>
      <th>No Induk</th>
      <th>NISN</th>
      <th>Nama Siswa</th>
      <th>Kehadiran</th>
    </thead>
    <tbody>
    <tr></tr>
      <?php $no = 1;
      foreach ($absen as $key) { ?>
        <tr>
          <td><?= $no; ?></td>
          <td>
            <?= $key->no_induk ?>
          </td>
          <td>
            <?= $key->NISN ?>
          </td>
          <td>
            <?= $key->NamaSiswa ?>
          </td>
          <td>
            <?= $key->keterangan ?>
          </td>
        </tr>
      <?php $no++;
      } ?>
    </tbody>
  </table>
</body>

</html>